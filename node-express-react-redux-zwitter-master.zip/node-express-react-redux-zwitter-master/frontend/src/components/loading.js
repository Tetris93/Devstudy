// Imports
import React from 'react'

// UI Imports
import CircularProgress from 'material-ui/CircularProgress'

const Layout = () => (
  <CircularProgress/>
)

export default Layout
